import openpyxl

def recallroster(File_Path, TelephoneList_Name):
    

    # above and below will open the excel spreadsheet for modifying
    # using the "r" before introducing python to file path names will not show as escape sequences allowing python to read the path name for excel
    # as well as python reading \n as a new line instead of "C:\new_folder"
    excel_file = openpyxl.load_workbook(File_Path)
    TelephoneList = excel_file[TelephoneList_Name]
   
    while True:
        # This will give me the max row and columns to read the data and put it in a variable
        max_row = TelephoneList.max_row
        max_column = TelephoneList.max_column
        
        
        # Our for loop to start looping so Thonny can read the data.
        for row in range(2, max_row + 1):
            for column in range(2, max_column + 1):
            
                # This variable allows me python to reference my spreadsheet for the specific row and column.
                cell = TelephoneList.cell(row = row, column = column)
                
                if cell.value is not None: # This allows python to read if the cell value in the spread sheet is none
                    cell_value = cell.value
                else:
                    cell_value = "" # This assigns a empty string in the cell value for python to input


                # if, elif, else statements to create formatting for easy to read code in Thonny.
                if column == 1:
                    # Last Name
                    print("{:<15}".format(cell_value), end = " ")
                elif column == 3:
                    # Spouse/Kids
                    print("{:<13}".format(cell_value), end = " ")
                elif column == 4:
                    # Address
                    print("{:<15}".format(cell_value), end = " ")
                elif column == 5:
                    # Home Phone
                    print("{:<20}".format(cell_value), end = " ")
                elif column == 7:
                    # Cell
                    print("{:<20}".format(cell_value), end = " ")
                else:
                    # Email
                    print("{:<20}".format(cell_value), end = " ")
                    
            print()  # Print a newline after each row
       
       
       
        # Prompt user to search for name or enter new record
        name = input("\nEnter the name for who you are looking to fire or hire press H for \"Hiring\" F for \"Firing\": \n").strip()
        
        
        
        if name.lower() == "h":
            new_data = [] # add a list for the information for a new record
            print("Add the info for the new chump: ")
            
            fields = ["Last Name", "First Name", "Spouse/Kids", "Address", "Home Phone", "Work Phone", "Cell Phone", "Email"] # Fields for python to read excel
            for field in fields: # Start a for loop to input data
                value = input("{}: ".format(field)).strip()
                
                if field in ["Last Name", "First Name"]:
                    value = value.capitalize() # Capitalizes the first initial for each name
                elif field == "Spouse/Kids": # This will automatically change values y/n to be Yes and No
                    if value.lower() == "y":
                        value = "Yes"
                    elif value.lower() == "n":
                        value = "No"                
                elif "Phone" in field:
                    value = value.replace("-", "").replace("(", "").replace(")", "").replace(" ", "") # adds the hyphens to a 10 digit number automatically
                    if len(value) == 10:
                        value = value[:3] + "-" + value[3:6] + "-" + value[6:] #indices the number placement value in lists 0 thru 6
                        
                new_data.append(value) # append new data to add to excel
                
            new_row = TelephoneList.max_row + 1 # This will add a new row to excel spreadsheet
            
            for column, value in enumerate(new_data, start = 2): # I need python to read excel at column 2, since column 1 is empty and excel starts with 1 instead of python starting at 0
                TelephoneList.cell(row = new_row, column = column).value = value
            
            excel_file.save(File_Path)
            print("\nRecord has been saved: \n")
        
        elif name == "f":
            delete_name = input("Name of employee to delete: ")
            found = False
            for row in range(2, max_row + 1): # For loop for python to search for the name in the rows and columns of excel
                name_cell = TelephoneList.cell(row = row, column = 2)
                if delete_name == name_cell.value.lower():
                    # Added a confirmation for deletion since there will not be a way to pull the data back into excel once deleted through python
                    confirmation = input("This will permanently fire employee {} record are you sure? ".format(delete_name)).strip().lower()
                    
                    if confirmation == "yes" or confirmation == "y": # This will check to see what the user inputted for the confirmation
                        TelephoneList.delete_rows(row, 1)
                        excel_file.save(File_Path)
                        print("\nEmployee has been terminated\n")
                    else:
                        print("Employee is barely holding on to this job: \n")  # Gives user the confirmation that the record was deleted
                                    
                    found = True  # I assigned the found variable to false at first so once the data was found we need to assign it true for record deletion
                    break
            if not found:
                print("\nEmployee probably already got fired\n")
   
        else:
            found = False
            for row in range(2, TelephoneList.max_row + 1): # This for loop will allow me to search the record and pull the data up in the same format to make legible
                name_cell = TelephoneList.cell(row = row, column = 2)
                if name.lower() in name_cell.value.lower():
                    found = True
                    total_length = 0

                    for column in range(2, TelephoneList.max_column + 1):
                        cell = TelephoneList.cell(row = row, column = column)
                        cell_value = (cell.value if cell.value is not None else "").upper()
                        if column == 1:
                            total_length += 15
                            print("{:<15}".format(cell_value), end=" ")
                        elif column == 3:
                            total_length += 13
                            print("{:<13}".format(cell_value), end=" ")
                        elif column == 4:
                            total_length += 15
                            print("{:<15}".format(cell_value), end=" ")
                        elif column == 5:
                            total_length += 20
                            print("{:<20}".format(cell_value), end=" ")
                        elif column == 7:
                            total_length += 20
                            print("{:<20}".format(cell_value), end=" ")
                        else:
                            total_length += 20
                            print("{:<20}".format(cell_value), end=" ")
                    
                    update = input("\nWould you like to change them? (y/n): ").strip().lower()  # This variable and for loop allows me to update each particular field
                    if update == "yes" or update == "y":
                        fields = ["Last Name", "First Name", "Spouse/Kids", "Address", "Home Phone", "Work Phone", "Cell Phone", "Email"]
                        print("Enter the new info for the chump")
                        for column, field in enumerate(fields, start = 2): # This allows python to find the data in the spreadsheet for the fields
                            current_value = TelephoneList.cell(row = row, column = column).value or ""
                            new_value = input("{} [{}]: ".format(field, current_value)).strip()  # Changes the data for the field, user prompt associated with for each
                            
                            if field in ["Last Name", "First Name"]:
                                new_value = new_value.capitalize()
                            elif field == "Spouse/Kids":
                                if new_value.lower() in ["y", "yes"]:
                                    new_value = "Yes"
                                elif new_value.lower() in ["n", "no"]:
                                    new_value = "No"
                            elif "Phone" in field:
                                new_value = new_value.replace("-", "").replace("(", "").replace(")", "").replace(" ", "")
                                if len(new_value)== 10:
                                    new_value = "{}-{}-{}".format(new_value[:3], new_value[3:6], new_value[6:])
                                    
                            TelephoneList.cell(row = row, column = column).value = new_value
                            
                        excel_file.save(File_Path)
                        print("Employee retained.")
                        
                    print("-" * total_length)  # This allows me to make a dashed line to give a better perception for the user
                    input("Press enter to startover: ")
                    break
            if not found:
                print("No employee listed by that name probably already fired lol :)")
                return
                
    excel_file.close()    # Saves excel_file and closes it

    

recallroster(r"C:\Users\ryan7\OneDrive\FSC\ProjectProposal\Employee_phone_list.xlsx", "TelephoneList")   
    
    
    
    
    